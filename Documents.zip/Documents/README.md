To edit Project Proposal, find the associated .tex file. 
To edit the Progress Report, find the associated .tex file.
To edit the Final report, find the associated .tex file.

The only files you should be changing are these three, along
with APS360_ref.bib. When you want to add in a reference, 
add in all the information into APS360 in a relvant format.
You will be then be free to use this source for citation 
in any of the tex files.

I've made sure to add in the extra files that latex generates
into the git ignore, so don't worry about that too much, unless
you notice some mistake.
